package com.example.midtermexam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
