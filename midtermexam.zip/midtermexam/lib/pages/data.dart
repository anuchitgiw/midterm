import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:midtermexam/pages/detail.dart';
import 'package:http/http.dart' as http;
import 'dart:async';

class DataPage extends StatefulWidget {
  // const Data({ Key? key }) : super(key: key);

  @override
  _DataPageState createState() => _DataPageState();
}

class _DataPageState extends State<DataPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(title: Text("SMCU")),
      body: Padding(
          padding: const EdgeInsets.all(20),
          child: FutureBuilder(
            builder: (context, AsyncSnapshot snapshot) {
              //var data = json.decode(snapshot.data.toString());
              return ListView.builder(
                itemBuilder: (BuildContext context, int index) {
                  return MyBox(snapshot.data[index]['province'],
                      snapshot.data[index]['total_case'], context);
                },
                itemCount: snapshot.data,
              );
            },
            future: getData(),
            // DefaultAssetBundle.of(context).loadString('assets/data.json'),
          )),
    );
  }
}

Widget MyBox(String province, String total_case, context) {
  var v1, v2, v3;
  v1 = province;
  v2 = total_case;
  v3 = context;
  return Container(
    // color: Colors.green[200],
    height: 150,
    margin: EdgeInsets.all(20),
    padding: EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: Colors.green[100],
      borderRadius: BorderRadius.circular(20),
      // image: DecorationImage(image: NetworkImage(image_url), fit: BoxFit.cover),
    ),
    child: (Column(
      mainAxisAlignment: MainAxisAlignment.center,
      // start บนๆ
      crossAxisAlignment: CrossAxisAlignment.center,
      //  start ซ้ายๆ
      children: [
        // Image.asset('assets/images/pizza.jpg',width: 300,),
        Text(
          province,
          style: TextStyle(
              fontSize: 10,
              color: Colors.green[100],
              fontWeight: FontWeight.bold),
          // (fontSize: 25,fontWeight: FontWeight.bold,color: Colors.red[100])
        ),
        Text(
          total_case,
          style: TextStyle(fontSize: 10),
        ),

        SizedBox(height: 20),
        TextButton(
          onPressed: () {
            print("Next Page >>>");
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => DetailPage(v1, v2, v3)));
          },
          child: Text("Next page >>>"),
        )
      ],
    )),
  );
}

Future getData() async {
  //https://raw.githubusercontent.com/anuchitgiw/BASICAPI/main/data.json
  var url = Uri.https(
      'raw.githubusercontent.com', '/anuchitgiw/midterm/main/datamid.json');
  var response = await http.get(url);
  var result = json.decode(response.body);
  return result;
}
