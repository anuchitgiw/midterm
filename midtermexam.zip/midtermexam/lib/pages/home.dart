import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  //  const HomePage({ Key? key }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  // double price = 10;
  TextEditingController result = TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    result.text = "ยินดีต้อนรับคุณ...";
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(50.0),
          child: Center(
            child: Column(
              children: [
                Image.asset(
                  'images/001.jpg',
                  width: 300,
                ),
                Text("Login เข้าสู่ระบบ", style: TextStyle(fontSize: 30)),
                TextField(
                  // decoration: InputDecoration(
                  controller: username,
                  decoration: InputDecoration(
                      labelText: 'Username', border: OutlineInputBorder()),
                ),
                SizedBox(height: 20),
                TextField(
                  // decoration: InputDecoration(
                  controller: password,
                  decoration: InputDecoration(
                      labelText: 'Password', border: OutlineInputBorder()),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    // var cal = String.parse(username.text);
                    // print("Apple Quantity : ${username.text}Total:$cal Bath");
                    setState(() {
                      result.text = "ยินดีต้อนรับคุณ ${username.text} ";
                    });
                  },
                  child: Text("เข้าสู่ระบบ"),
                  style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(Color(0xff3300CC)),
                      padding: MaterialStateProperty.all(
                          EdgeInsets.fromLTRB(50, 20, 50, 20)),
                      textStyle:
                          MaterialStateProperty.all(TextStyle(fontSize: 30))),
                ),
                Text(
                  result.text,
                  style: TextStyle(fontSize: 20),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}
